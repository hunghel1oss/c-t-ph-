import apiClient from './interceptor';
import { API_ENDPOINTS } from '../config/constants';

/**
 * Auth API
 */

export const authAPI = {
  /**
   * Đăng ký
   * @param {Object} data - { name, email, password }
   */
  register: async (data) => {
    const response = await apiClient.post(API_ENDPOINTS.AUTH.REGISTER, data);
    return response.data;
  },
  
  /**
   * Đăng nhập
   * @param {Object} data - { email, password }
   * @returns {Object} { user, accessToken, refreshToken }
   */
  login: async (data) => {
    const response = await apiClient.post(API_ENDPOINTS.AUTH.LOGIN, data);
    return response.data;
  },
  
  /**
   * Refresh token
   * @param {string} refreshToken
   * @returns {Object} { accessToken }
   */
  refreshToken: async (refreshToken) => {
    const response = await apiClient.post(API_ENDPOINTS.AUTH.REFRESH, {
      refreshToken,
    });
    return response.data;
  },
  
  /**
   * Đăng xuất
   */
  logout: async () => {
    const response = await apiClient.post(API_ENDPOINTS.AUTH.LOGOUT);
    return response.data;
  },
};
