import apiClient from './interceptor';
import { API_ENDPOINTS } from '../config/constants';

/**
 * Game API (REST endpoints)
 * Phần lớn logic game sẽ qua WebSocket
 */

export const gameAPI = {
  /**
   * Tạo phòng (có thể dùng REST hoặc Socket)
   * @param {Object} data - { hostId, duration }
   */
  createRoom: async (data) => {
    const response = await apiClient.post(API_ENDPOINTS.GAME.CREATE, data);
    return response.data;
  },
  
  /**
   * Join phòng (có thể dùng REST hoặc Socket)
   * @param {Object} data - { roomCode, userId }
   */
  joinRoom: async (data) => {
    const response = await apiClient.post(API_ENDPOINTS.GAME.JOIN, data);
    return response.data;
  },
  
  /**
   * Lấy danh sách phòng
   */
  listRooms: async () => {
    const response = await apiClient.get(API_ENDPOINTS.GAME.LIST);
    return response.data;
  },
  
  /**
   * Lấy thông tin phòng
   * @param {string} roomCode
   */
  getRoomInfo: async (roomCode) => {
    const response = await apiClient.get(`/api/game/room/${roomCode}`);
    return response.data;
  },
};
