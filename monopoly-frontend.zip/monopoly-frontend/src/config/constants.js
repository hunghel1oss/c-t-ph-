// Game constants - phải khớp với backend
export const GAME_SETTINGS = {
  STARTING_MONEY: 3000,
  PASS_GO_BONUS: 300,
  MAX_PLAYERS: 4,
  MIN_PLAYERS: 2,
  JAIL_POSITION: 8,
  JAIL_FINE: 50,
  MAX_JAIL_TURNS: 3,
  BOARD_SIZE: 32,
};

export const DURATION_OPTIONS = [
  { value: 20, label: '20 phút' },
  { value: 60, label: '60 phút' },
];

export const PET_TYPES = ['lion', 'dragon', 'unicorn', 'phoenix'];

export const PET_COLORS = {
  lion: '#FFD700',      // Vàng
  dragon: '#FF4500',    // Đỏ cam
  unicorn: '#FF10F0',   // Hồng neon
  phoenix: '#00F0FF',   // Xanh neon
};

export const SQUARE_TYPE_COLORS = {
  start: '#39FF14',       // Xanh lá neon
  property: '#00F0FF',    // Xanh dương neon
  railroad: '#FFFF00',    // Vàng neon
  utility: '#FF6600',     // Cam neon
  tax: '#FF0000',         // Đỏ
  chance: '#FF10F0',      // Hồng neon
  community: '#BF00FF',   // Tím neon
  jail: '#808080',        // Xám
  plane: '#FF0000',       // Đỏ (go to jail)
  festival: '#39FF14',    // Xanh lá
  free_parking: '#FFD700', // Vàng
};

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: '/api/auth/login',
    REGISTER: '/api/auth/register',
    REFRESH: '/api/auth/refresh',
    LOGOUT: '/api/auth/logout',
  },
  GAME: {
    CREATE: '/api/game/create',
    JOIN: '/api/game/join',
    LIST: '/api/game/list',
  },
};
